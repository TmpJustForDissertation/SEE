This is a brief guide for using the MACOED (Matlab version) (multi-objective ant colony optimization algorithm for SNP epistasis detection) for epistasis detecting in Genome-wide association study (GWAS).

This package contains 6 flies: "macoed_main.m": the main program of MACOED; "acomop_seek.m": the ant colony optimization part of the MACOED; "multiscore.m": the computation of multi-score; "non_domination_sort.m": the non-dominated sort algorithm part; "Chisquare_test.m": the Chi-square test part; "Chisquare_score.m": the computation of Chi-square score 

1) Input Format

The user should create a comma-delimited file which contains the case-control genotype data. The first line of the input file contains the SNP IDs and the name for the dependent variable (last column).The following lines are the genotype data and the disease state with each line corresponding to one individual. The genotype data should be indexed as 0, 1, 2 which correspond to the homozygous major allele, heterozygous allele, and homozygous minor allele respectively.The disease state should be indexed as 0 and 1 which represent control and case respectively.
The following is a sample data file for 10 individuals (5 cases and 5 controls) each genotyped for 20 SNPs.

X0,X1,X2,X3,X4,X5,X6,X7,X8,X9,X10,X11,X12,X13,X14,X15,X16,X17,X18,X19,Class
0,0,0,1,0,0,1,1,0,1,0,1,1,0,1,2,0,1,0,0,0
0,2,0,2,1,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0
1,0,0,1,1,1,0,2,1,1,1,0,0,0,1,1,1,2,1,0,1
0,1,0,0,1,0,0,0,0,1,0,1,0,0,0,0,2,1,0,1,1
1,1,0,0,1,0,0,1,0,0,0,0,1,1,0,0,0,0,1,1,0
0,0,1,0,0,0,0,0,0,0,1,1,1,0,0,0,1,0,0,0,1
0,0,1,1,1,1,0,0,1,0,0,0,0,0,0,1,0,1,1,0,0
0,0,1,1,0,0,0,0,0,0,1,0,1,1,0,0,0,2,0,1,0
0,0,1,2,0,0,1,2,0,1,1,0,0,0,0,0,1,0,0,1,1
0,0,0,0,0,0,1,0,0,0,0,0,0,2,0,0,0,0,0,0,1

2) Parameters

The users can set the parameters mentioned in the paper in the "macoed_main.m".There are 8 parameters need to specified:  "tau": initial pheromone level for each locus; "threshold": used to determing convergence speed and solutions diversity; "rou": evaporation rate in Ant Colony Optimizaion; "lambda": weight coefficient to non-dominated solutions; "num_ant" number of ants in iteration; "max_iter": number of iteration; "dim_epi": the dimension of epistatic iteraction to detect; "alpha": p value threshold after Bonferroni correction;

3) Output

The results are stored in the matrix "aco_accuracy". 

4) Support
If you have any questions please contact to Peng-Jie Jing (jingse@sjtu.edu.cn) or Hong-Bin Shen (hbshen@sjtu.edu.cn).


