function global_subsets = acomop_seek(data,dim_epi,num_ant,max_iter)
%input--------------------------------------------------------------------
% data-----------------input dataset
% epi_dim--------------the epistasis dimension
% ant_num--------------the number of ants
% acoitt---------------the max iteration of the algorithm
%arguments----------------------------------------------------------------
% tau0---------------initial pheromone level
% T0-----------------parameter determining convergence speed and solutions diversity
% rou----------------evaporation rate in Ant Colony Optimizaion
% lambda-------------weight coefficient to non-dominated solutions
%%-------------------------------------------------------------------------
% initial arguments
tau0 = 1;
T0 = 0.8;
rou = 0.9;
lambda = 2;
%% ---------------------------------------------------------------
n=size(data,2);
State=data(:,n);
n=n-1;
Tau=ones(n,n);
NC=1;
obj = 2;
flag=zeros(n,n);
times=zeros(n,n);
SCORE=cell(n,n);
global_subsets = [];
p = zeros(1,n);
%%-------------------------------------------------------------------------
while NC <= max_iter      
    iteration = NC
    Tabu=zeros(num_ant,dim_epi);
    Randpos = randperm(n);
    for e = 1:num_ant
        Tabu(e,1) = Randpos(e);
    end
    for i=1:num_ant
        m_iLociCount = 1;
        for j = 2:dim_epi
            for k = 1:n
                p(k) = Tau(Tabu(i,m_iLociCount),k)^tau0;
            end
            p=p/(sum(p));
            pcum = cumsum(p);
            jj = -1;
            while(jj == -1)
                jj = 0;
                mRate = rand;
                roulette = rand;
                if mRate >= T0
                    select = ceil(roulette*n);
                else
                    select = find(pcum >= roulette,1);
                end
                for mi=1:m_iLociCount
                    if(select == Tabu(i,mi))
                        jj = -1;
                        break;
                    end
                end
            end
            m_iLociCount = m_iLociCount+1;
            Tabu(i,m_iLociCount) = select;
        end
    end
    Tabu = sort(Tabu,2);
    Tabu = unique(Tabu,'rows');
    score = [];
    for j = 1:size(Tabu,1)
        if flag(Tabu(j,1),Tabu(j,2)) == 1
            score(j,:) = SCORE{Tabu(j,1),Tabu(j,2)};
            times(Tabu(j,1),Tabu(j,2)) = times(Tabu(j,1),Tabu(j,2))+1;
        else
            snp_com = data(:,Tabu(j,:));
            [score(j,1),score(j,2)] = multiscore(snp_com,State);
            flag(Tabu(j,1),Tabu(j,2)) = 1;
            SCORE{Tabu(j,1),Tabu(j,2)} = [score(j,1),score(j,2)];
            times(Tabu(j,1),Tabu(j,2)) = times(Tabu(j,1),Tabu(j,2))+1;
        end
    end
    
    if NC>1
        temp_tabu = [Tabu;local_tabu];
        temp_score = [score;local_score];
    else
        temp_tabu = Tabu;
        temp_score = score;
    end
    [temp_tabu,ia,~] = unique(temp_tabu,'rows');
    temp_score1 = [];
    for i =1:size(ia,1)
        temp_score1(i,1:dim_epi) = temp_score(ia(i),:);
    end
    temp_score = temp_score1;
    F = non_domination_sort(temp_score);
    local_tabu = [];
    local_score = [];
    for i = 1:size(F,2)
        local_tabu(i,1:dim_epi) = temp_tabu(F(i),:);
        local_score(i,1:obj) = temp_score(F(i),:);
    end
    
    for k=1:dim_epi
        for r=1:dim_epi
            if k~=r
                for j=1:size(temp_tabu,1)
                    Tau(temp_tabu(j,k),temp_tabu(j,r))=rou*Tau(temp_tabu(j,k),temp_tabu(j,r)); 
                end
                for i = 1:size(F,2)
                    Tau(local_tabu(i,k),local_tabu(i,r)) = ...
                        Tau(local_tabu(i,k),local_tabu(i,r)) + (1-rou)*lambda;
                end
            end
        end
    end
    
    NC=NC+1;
    
end
for i = 1:size(local_tabu,1)
    global_subsets = [global_subsets local_tabu(i,:)];
end
global_subsets = sort(global_subsets);
global_subsets = unique(global_subsets);




