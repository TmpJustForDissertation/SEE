%% MACOED.m  multi-objective ant colony optimization in  problem.
clc;clear;
samplesize = 1600;
data_num = 100;
dim = 100;
Bp = 0.1;
dim_epi = 2;
num_ant = dim;
max_iter = 100;
comb = nchoosek(dim,dim_epi);
pvalue = Bp/comb;
slash = '\';
root = ['D:',slash,num2str(samplesize),slash];

tic
for m = 0
    if m<10
        model = ['0',num2str(m)];
    else model = num2str(m);
    end
    seek_size = zeros(100,1);
    final_size = zeros(100,1);
    intermediate = cell(100,1);
    final = cell(100,1);
    ac = 0;
    ac_inter = 0;
    for d = 0:data_num-1
        model_iteration = m
        data_iteration = d
        filename = [root,model,slash,model,'.',num2str(samplesize),'.',num2str(d),'.txt'];
        a = dlmread(filename,'\t',1,0);
        data = a(:,[1:dim end]);
        % step 1 : screen step
        filter_snps = acomop_seek(data,dim_epi,num_ant,max_iter);
        k = d+1;
        seek_size(k) = size(filter_snps,2);
        intermediate{k,1} = filter_snps;
        flag = 0;
        if ~isempty(filter_snps) && filter_snps(1) == 1 && filter_snps(2) == 2;
            ac_inter = ac_inter+1;
            flag = 1;
        end
        % step 2 : clean step
        epistatic = Chisuqare_test(data,filter_snps,dim_epi,pvalue);
        final{k,1} = epistatic;
        final_size(k) = size(epistatic,1);
        if ~isempty(epistatic)
            if epistatic(1,1) == 1 && epistatic(1,2) == 2
                ac = ac+1;
            end
        end
    end
    inter_len = mean(seek_size);
    final_len = mean(final_size);
    % statistics
    l = m+1;
    aco_accuracy(l,1:4) = [ac_inter ac inter_len final_len];
    aco_snp{l,1} = intermediate;
    aco_snp{l,2} = final;
    aco_snp{l,3} = seek_size;
    aco_snp{l,4} = final_size;
end
time = toc;

