function [score1,score2] = multiscore(snp_com,state)
[xrow,~] = size(snp_com);
%% K2 score 
subs = snp_com+1;
sample = accumarray(subs,ones(xrow,1));
disease = accumarray(subs,state);
control = sample-disease;
sample(4,4) = 0;
disease(4,4) = 0;
control(4,4) = 0;
z=0;
for i = 1:3
    for j = 1:3
        y=My_factorial(sample(i,j)+1);
        r=My_factorial(disease(i,j))+My_factorial(control(i,j));
        z=z+(r-y);
    end
end
score1=abs(z);
%% AIC score
addint = [snp_com(:,1),snp_com(:,2),snp_com(:,1).*snp_com(:,2)];
[~,~,stats] = glmfit(addint, [state ones(xrow,1)], 'binomial', 'link', 'logit');
predict = state-stats.resid; 
para = size(addint,2)+1;
p = abs(1-state-predict);
aic = sum(log(p));
aic = -2*aic+2*para;
score2 = aic;
%% f is function used to calculate log form factorial
    function f=My_factorial(e)
        f=0;
        if e>0
            for o=1:e
                f=f+log(o);
            end
        end
    end
end


