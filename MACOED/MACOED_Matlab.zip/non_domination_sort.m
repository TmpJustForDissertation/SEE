function F = non_domination_sort(score)
% classify the score to non-dominated set and donminated set

[N, ~] = size(score);
F = [];
for li = 1 : N
    flag = 0;
    for lj = 1 : N
        if ((score(lj,1)<score(li,1))&&(score(lj,2)<score(li,2)))||((score(lj,1)<score(li,1))&&(score(lj,2)==score(li,2))) ...
                ||((score(lj,1)==score(li,1))&&(score(lj,2)<score(li,2)))
            flag = 1;
            break;
        end
    end
    if flag == 0
        F = [F li];
    end
end
F = sort(F);
F = unique(F);













